<script>
import Vue from 'vue';

export default {
  name: "AdminComponent",
  components: {
  },
  data() {
    return {
      User : {
        username: "",
        password: "",
        isAdmin: false
      },
      apis: []
    };
  },
  methods: {

    isAdmin() {
      console.log("Admin");
      console.log(this.User);
    },

    getAllApis() {
    fetch("http://localhost:8080/apis/getAllApis", {
      mode: 'cors'
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      this.apis = data;
    })
    .catch(error => {
      console.error('There was a problem with the fetch operation:', error);
      this.apis = [];  // Reset apis or set a default state
    });
  },
  editCell(api, field) {
  // Set the 'editing' property of the API object to true
  Vue.set(api, 'editing', true);

  // Save the original value of the field being edited
  api.originalValue = api[field];
},

  saveEdit(api, field) {
    // Set the 'editing' property of the API object to false
    api.editing = false;

    // You can perform any additional logic here, such as sending updated data to the server
  },


  },
  mounted() {
    this.getAllApis();
  },
};
</script>
<template>
  <h1>Admin Panel</h1>
  
  <div class="responsive-table">
    <table>
      <tr>
        <th>API Name</th>
        <th>API URL</th>
        <th>API Description</th>
      </tr>
      <tr v-for="(api, index) in apis" :key="api.id">
        <td @click="editCell(api, 'name')">
          <span v-if="!api.editing">{{ api.name }}</span>
          <input v-else type="text" v-model="api.name" @blur="saveEdit(api, 'name')" @keyup.enter="saveEdit(api, 'name')">
        </td>
        <td @click="editCell(api, 'url')">
          <span v-if="!api.editing">{{ api.url }}</span>
          <input v-else type="text" v-model="api.url" @blur="saveEdit(api, 'url')" @keyup.enter="saveEdit(api, 'url')">
        </td>
        <td @click="editCell(api, 'json')">
          <span v-if="!api.editing">{{ api.json }}</span>
          <input v-else type="text" v-model="api.json" @blur="saveEdit(api, 'json')" @keyup.enter="saveEdit(api, 'json')">
        </td>
      </tr>
    </table>
  </div>

</template>

<style>
table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ccc;
}

th {
  background-color: #ccc;
}
.responsive-table {
  overflow-x: auto;
}
</style>
