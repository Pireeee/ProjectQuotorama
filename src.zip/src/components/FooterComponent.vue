<script></script>
<template>
  <footer>
    <div id="footer">
      <p>© 2021 Quotorama</p>
      <p>
        <RouterLink to="/cgu">CGU</RouterLink>
      </p>
    </div>
  </footer>
</template>
<style>
footer {
  /* CSS pour le footer */
  background: linear-gradient(to right, #f12711, #f5af19);
  text-align: center;
  border-top: 1px solid #ccc;
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 5rem;
}
a {
  color: #fff;
  text-decoration: none;
}
</style>
